// import { xxx } from '../services/xxx';
export default {
  namespace: "idsvr4",
  state: {},
  effects: {
    *fetch({ payload }, { call, put }) {
    },
  },
  reducers: {
    save(state, action) {
      return {
        ...state,
      };
    },
  },
};

